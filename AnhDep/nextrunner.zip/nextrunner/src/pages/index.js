import { useRouter } from 'next/router'

const Hello = () => {

  return <p>Hello world</p>
}

export default Hello